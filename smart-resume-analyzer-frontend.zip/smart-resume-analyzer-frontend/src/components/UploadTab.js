import React, { useState } from "react";
import { uploadResume } from "../api";

function UploadTab() {
  const [file, setFile] = useState(null);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);

  const handleUpload = async () => {
    if (!file) return alert("Please select a PDF file");
    setLoading(true);

    try {
      const response = await uploadResume(file);
      setResult(response.data);
    } catch (err) {
      console.error(err);
      alert("Failed to upload or analyze resume");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <h2>Upload Resume</h2>
      <input
        type="file"
        accept="application/pdf"
        onChange={(e) => setFile(e.target.files[0])}
      />
      <button onClick={handleUpload}>Upload</button>

      {loading && <p>Analyzing...</p>}

      {result && (
        <div>
          <h3>Analysis Result</h3>
          <p><strong>Name:</strong> {result.extracted_data.name}</p>
          <p><strong>Email:</strong> {result.extracted_data.email}</p>
          <p><strong>Phone:</strong> {result.extracted_data.phone}</p>
          <p><strong>Resume Rating:</strong> {result.llm_analysis.resume_rating}</p>
          <p><strong>Improvement Areas:</strong> {result.llm_analysis.improvement_areas}</p>
          <p><strong>Upskill Suggestions:</strong></p>
          <ul>
            {result.llm_analysis.upskill_suggestions.map((s, idx) => (
              <li key={idx}>{s.skill}: {s.reason}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default UploadTab;
