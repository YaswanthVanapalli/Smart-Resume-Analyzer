import React, { useState, useEffect } from "react";
import { fetchResumeDetail } from "../api";

function ResumeDetailModal({ resumeId, onClose }) {
  const [resume, setResume] = useState(null);

  useEffect(() => {
    const loadResume = async () => {
      try {
        const response = await fetchResumeDetail(resumeId);
        setResume(response.data);
      } catch (err) {
        console.error("Failed to fetch resume details", err);
      }
    };
    loadResume();
  }, [resumeId]);

  if (!resume) return <p>Loading...</p>;

  return (
    <div style={{ border: "1px solid black", padding: "20px", marginTop: "20px" }}>
      <h3>Resume Details</h3>
      <p><strong>ID:</strong> {resume.id}</p>
      <p><strong>Filename:</strong> {resume.filename}</p>
      <p><strong>Name:</strong> {resume.extracted_data.name}</p>
      <p><strong>Email:</strong> {resume.extracted_data.email}</p>
      <p><strong>Phone:</strong> {resume.extracted_data.phone}</p>
      <p><strong>Resume Rating:</strong> {resume.llm_analysis.resume_rating}</p>
      <p><strong>Improvement Areas:</strong> {resume.llm_analysis.improvement_areas}</p>
      <h4>Upskill Suggestions:</h4>
      <ul>
        {resume.llm_analysis.upskill_suggestions.map((s, idx) => (
          <li key={idx}>{s.skill}: {s.reason}</li>
        ))}
      </ul>
      <button onClick={onClose}>Close</button>
    </div>
  );
}

export default ResumeDetailModal;
