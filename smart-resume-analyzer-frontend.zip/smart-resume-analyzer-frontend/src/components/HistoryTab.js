import React, { useState, useEffect } from "react";
import { fetchResumes } from "../api";
import ResumeDetailModal from "./ResumeDetailModal";

function HistoryTab() {
  const [resumes, setResumes] = useState([]);
  const [selectedResume, setSelectedResume] = useState(null);

  useEffect(() => {
    const loadData = async () => {
      try {
        const response = await fetchResumes();
        setResumes(response.data);
      } catch (err) {
        console.error("Failed to fetch resumes", err);
      }
    };
    loadData();
  }, []);

  return (
    <div>
      <h2>Uploaded Resumes</h2>
      <table border="1" cellPadding="5">
        <thead>
          <tr>
            <th>ID</th>
            <th>Filename</th>
            <th>Uploaded At</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {resumes.map((resume) => (
            <tr key={resume.id}>
              <td>{resume.id}</td>
              <td>{resume.filename}</td>
              <td>{resume.uploaded_at}</td>
              <td>
                <button onClick={() => setSelectedResume(resume.id)}>
                  Details
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {selectedResume && (
        <ResumeDetailModal
          resumeId={selectedResume}
          onClose={() => setSelectedResume(null)}
        />
      )}
    </div>
  );
}

export default HistoryTab;
