import React, { useState } from "react";
import UploadTab from "./components/UploadTab";
import HistoryTab from "./components/HistoryTab";

function App() {
  const [activeTab, setActiveTab] = useState("upload");

  return (
    <div className="App">
      <header>
        <button onClick={() => setActiveTab("upload")}>Upload</button>
        <button onClick={() => setActiveTab("history")}>History</button>
      </header>

      <main>
        {activeTab === "upload" && <UploadTab />}
        {activeTab === "history" && <HistoryTab />}
      </main>
    </div>
  );
}

export default App;
